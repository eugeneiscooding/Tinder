//
//  datatypes.swift
//  Tinder
//
//  Created by Kavsoft on 26/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import Foundation
import SwiftUI


struct datatype : Identifiable {
    
    var id : String
    var name : String
    var image : String
    var age : String
    var swipe : CGFloat
    var degree : Double
}
