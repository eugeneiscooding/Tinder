//
//  Loader.swift
//  Tinder
//
//  Created by Kavsoft on 26/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

import SwiftUI


struct Loader : UIViewRepresentable {
    
    func makeUIView(context: UIViewRepresentableContext<Loader>) -> UIActivityIndicatorView {
        
        let indicator = UIActivityIndicatorView(style: .large)
        indicator.startAnimating()
        return indicator
    }
    
    func updateUIView(_ uiView: UIActivityIndicatorView, context: UIViewRepresentableContext<Loader>) {
        
        
    }
}
