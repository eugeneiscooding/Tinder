//
//  ContentView.swift
//  Tinder
//
//  Created by Kavsoft on 26/10/19.
//  Copyright © 2019 Kavsoft. All rights reserved.
//

//import your google info.plist to avoid errors

import SwiftUI
import Firebase
import SDWebImageSwiftUI


struct ContentView: View {
    
    @EnvironmentObject var obs : observer
    @State var showLiked = false
    
    var body: some View {
       
        ZStack{
            
            Color("LightWhite").edgesIgnoringSafeArea(.all)

            if obs.users.isEmpty{
                
                Loader()
            }
            
            VStack{
                
                TopView(show: $showLiked)
                
                SwipeView()
                
                BottomView()
            }
            
        }.sheet(isPresented: $showLiked) {
            
            LikedPeople()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// you can see that seen users are not displaying in the list.....
// in general zstack will overlay one view on another view so first
//index will be shown at last as well as last index will shown will be first.....
//time to clean code....

// User request...
// Show the list of liked people in a separate view...
// its showing list of liked people in a separate view.....


